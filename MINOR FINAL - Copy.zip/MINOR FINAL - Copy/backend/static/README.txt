This is the static folder for your Flask backend. Place your frontend files (HTML, CSS, JS, images) here so they are served from the same origin as your backend.

Example:
- exercise.html
- styles.css
- main.js

Access your frontend at: http://localhost:5000/static/exercise.html

You can move your existing frontend files into this folder for best compatibility and to avoid CORS issues.
